# Data Join and Plot Toolbox

##Ruby Dominick
##12/2/2025 

## Purpose
This ArcGIS Pro toolbox converts a GeoJSON file to a feature class,
joins a CSV table to it, applies a display option,
and creates a basic matplotlib graph based on the joined data.

## Data Used
Census Data
- User-provided CSV file
    -CensusCSV.csv
- User-provided GeoJSON file
    -P1807478266-2025-11-2800214609-MapLayer.json
  

## How to Use
1. Open ArcGIS Pro.
2. Add the toolbox `DataJoinPlotToolbox.pyt` to your project.
3. Run the tool:
   - Select a CSV file.
   - Select a GeoJSON file.
   - Select an output geodatabase.
   - Provide a feature class name.
   - Enter the name of the join attribute shared by both datasets.(GEOIDFQ)
   - Choose a display/symbology option.
   - Choose where to save the output PNG graph.
