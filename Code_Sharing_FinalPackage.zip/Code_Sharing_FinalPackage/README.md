# GeoJSON + CSV Processing Toolbox

## Author
Ruby Dominick  

## Date Created
November 2025

## Purpose of the Code
This ArcGIS Pro Python Toolbox (`.pyt`) automates the process of:
This code provides an automated workflow in ArcGIS Pro for converting a GeoJSON
file into a feature class, joining its data with a CSV table,
and generating a simple visualization of the joined data. 

---

## Data Accessed
Census data on education attainment 
### **User-provided inputs**
- **One CSV file**  
  ACSST5Y2023.S1501_2025-11-29T164232

- **One GeoJSON file**  
Census Tract-2025-11-29T21_40_42.095Z

## How to Run the Code Package

### **1. Download or clone the repository**
Download the entire project folder OR clone the GitHub repo onto your computer.

### **2. Open ArcGIS Pro**
Start ArcGIS Pro and open the provided project (`.aprx`) file.

### **3. Load the Python toolbox**
In the *Catalog* pane:
- Right-click **Toolboxes**
- Select **Add Toolbox**
- Navigate to:  
  `GeoJSON_CSV_Toolbox.pyt`
- Add it to your project

### **4. Run the Tool**
Double-click the tool:  
**GeoJSON to Feature Class + CSV Join**

The dialog will ask you to select:

1. CSV file  
2. GeoJSON file  
3. Output folder  
4. Join field name  
5. Display (symbology) option  
6. Output PNG path


All saved to the output folder you selected.

---

## Project Structure

